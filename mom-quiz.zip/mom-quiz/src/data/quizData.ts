export interface QuizQuestion {
  id: number;
  question: string;
  options: {
    text: string;
    points: number;
    momType: string;
  }[];
}

export interface MomType {
  id: string;
  title: string;
  scoreRange: [number, number];
  description: string;
  message: string;
  image: string;
  products: {
    name: string;
    description: string;
    amazonLink: string;
  }[];
}

export const quizQuestions: QuizQuestion[] = [
  {
    id: 1,
    question: "How do you typically start your day with your children?",
    options: [
      { text: "I wake up before them to prepare breakfast and organize their day", points: 4, momType: "Organized Mom" },
      { text: "We wake up together and figure it out as we go", points: 2, momType: "Go-with-Flow Mom" },
      { text: "I let them sleep in and we have a relaxed morning", points: 3, momType: "Nurturing Mom" },
      { text: "I'm rushing to get everyone ready while drinking coffee", points: 1, momType: "Busy Mom" }
    ]
  },
  {
    id: 2,
    question: "When your child misbehaves, what's your approach?",
    options: [
      { text: "Clear consequences that we discussed beforehand", points: 4, momType: "Structured Mom" },
      { text: "I explain why their behavior was wrong and we talk it through", points: 3, momType: "Communicative Mom" },
      { text: "Time-out and then a big hug to reconnect", points: 2, momType: "Balanced Mom" },
      { text: "I raise my voice then feel guilty about it later", points: 1, momType: "Stressed Mom" }
    ]
  },
  {
    id: 3,
    question: "How do you handle feeding your family?",
    options: [
      { text: "Meal prep on Sundays with balanced, nutritious meals planned", points: 4, momType: "Super Organized Mom" },
      { text: "I cook most meals but sometimes we order takeout", points: 3, momType: "Practical Mom" },
      { text: "We eat whatever I can quickly throw together", points: 2, momType: "Survival Mom" },
      { text: "Cereal for dinner happens more often than I'd like to admit", points: 1, momType: "Overwhelmed Mom" }
    ]
  },
  {
    id: 4,
    question: "How do you spend one-on-one time with your children?",
    options: [
      { text: "Scheduled activities like reading, crafts, or educational games", points: 4, momType: "Engaged Mom" },
      { text: "We do whatever they're interested in that day", points: 3, momType: "Adaptive Mom" },
      { text: "Cuddling on the couch watching their favorite shows", points: 2, momType: "Relaxed Mom" },
      { text: "I try to but often get distracted by chores or my phone", points: 1, momType: "Distracted Mom" }
    ]
  },
  {
    id: 5,
    question: "How often do you take time for yourself?",
    options: [
      { text: "I have a regular self-care routine that I prioritize", points: 4, momType: "Self-Aware Mom" },
      { text: "When I can squeeze it in, usually once a week", points: 3, momType: "Realistic Mom" },
      { text: "Occasionally, when someone else can watch the kids", points: 2, momType: "Struggling Mom" },
      { text: "What's self-care? I can't remember the last time", points: 1, momType: "Burnt-out Mom" }
    ]
  },
  {
    id: 6,
    question: "What does your home typically look like?",
    options: [
      { text: "Organized with designated places for everything", points: 4, momType: "Tidy Mom" },
      { text: "Lived-in but generally clean and functional", points: 3, momType: "Normal Mom" },
      { text: "Cluttered but we know where most things are", points: 2, momType: "Relaxed Mom" },
      { text: "Chaos with toys and laundry everywhere", points: 1, momType: "Real Mom" }
    ]
  },
  {
    id: 7,
    question: "How involved are you in your child's learning?",
    options: [
      { text: "I supplement their education with additional activities and resources", points: 4, momType: "Academic Mom" },
      { text: "I help with homework and attend school events", points: 3, momType: "Supportive Mom" },
      { text: "I check in on their progress and help when they ask", points: 2, momType: "Available Mom" },
      { text: "I trust their teachers and try to stay on top of things", points: 1, momType: "Trusting Mom" }
    ]
  },
  {
    id: 8,
    question: "How do you handle your child's social activities?",
    options: [
      { text: "I coordinate playdates and activities well in advance", points: 4, momType: "Social Coordinator Mom" },
      { text: "I arrange activities when opportunities come up", points: 3, momType: "Flexible Mom" },
      { text: "We see friends when it naturally happens", points: 2, momType: "Easygoing Mom" },
      { text: "I barely manage our own schedule, let alone social activities", points: 1, momType: "Overwhelmed Mom" }
    ]
  },
  {
    id: 9,
    question: "On a typical day, how patient are you with your children?",
    options: [
      { text: "I rarely lose my cool and handle situations calmly", points: 4, momType: "Zen Mom" },
      { text: "I'm generally patient but have my moments", points: 3, momType: "Human Mom" },
      { text: "I try my best but sometimes I snap and then apologize", points: 2, momType: "Honest Mom" },
      { text: "I lose my patience often and feel terrible about it", points: 1, momType: "Struggling Mom" }
    ]
  },
  {
    id: 10,
    question: "How do you think about your children's future?",
    options: [
      { text: "I have detailed plans and goals for their development", points: 4, momType: "Planner Mom" },
      { text: "I think about it regularly and make decisions accordingly", points: 3, momType: "Thoughtful Mom" },
      { text: "I trust that things will work out as they grow", points: 2, momType: "Optimistic Mom" },
      { text: "I'm too focused on surviving today to think about tomorrow", points: 1, momType: "Survival Mom" }
    ]
  }
];

export const momTypes: MomType[] = [
  {
    id: "super-mom",
    title: "Super Mom",
    scoreRange: [35, 40],
    description: "You're incredibly organized and seem to have it all together!",
    message: "You prioritize your family while maintaining structure. You're the mom who has it all figured out, and other moms look up to you for inspiration. Remember that perfection isn't required - you're already amazing!",
    image: "/images/super-mom.png",
    products: [
      {
        name: "Erin Condren LifePlanner",
        description: "Perfect for staying organized and planning your family's activities",
        amazonLink: "https://www.amazon.com/s?k=Erin+Condren+LifePlanner&ref=nb_sb_noss"
      },
      {
        name: "168 Hours: You Have More Time Than You Think",
        description: "Time management strategies for busy, successful moms",
        amazonLink: "https://www.amazon.com/s?k=168+Hours+You+Have+More+Time&ref=nb_sb_noss"
      },
      {
        name: "OXO POP Food Storage Containers",
        description: "Keep your organized kitchen looking and functioning perfectly",
        amazonLink: "https://www.amazon.com/s?k=OXO+POP+Food+Storage+Containers&ref=nb_sb_noss"
      }
    ]
  },
  {
    id: "balanced-mom",
    title: "Balanced Mom",
    scoreRange: [25, 34],
    description: "You're doing a great job balancing all aspects of motherhood.",
    message: "You're human, realistic, and loving. You understand that motherhood is about finding balance, not perfection. You take care of your family while also remembering to take care of yourself. Keep up the wonderful work!",
    image: "/images/balanced-mom.jpg",
    products: [
      {
        name: "Essential Oil Diffuser",
        description: "Create a calming atmosphere for your balanced lifestyle",
        amazonLink: "https://www.amazon.com/s?k=Essential+Oil+Diffuser+for+Relaxation&ref=nb_sb_noss"
      },
      {
        name: "Family Board Games",
        description: "Perfect for quality family time and creating memories",
        amazonLink: "https://www.amazon.com/s?k=Board+Games+for+Family+Night&ref=nb_sb_noss"
      },
      {
        name: "The 5 Minute Journal",
        description: "Simple daily practice for gratitude and mindfulness",
        amazonLink: "https://www.amazon.com/s?k=The+5+Minute+Journal&ref=nb_sb_noss"
      }
    ]
  },
  {
    id: "real-mom",
    title: "Real Mom",
    scoreRange: [15, 24],
    description: "You're authentic and honest about the challenges of motherhood.",
    message: "You're doing your best in a demanding role, and that's exactly what your children need. Your authenticity and honesty make you relatable and real. Remember, the best moms aren't perfect - they're present and loving.",
    image: "/images/real-mom.png",
    products: [
      {
        name: "Adult Coloring Books for Stress Relief",
        description: "A peaceful way to unwind after long days",
        amazonLink: "https://www.amazon.com/s?k=Adult+Coloring+Books+for+Stress+Relief&ref=nb_sb_noss"
      },
      {
        name: "Instant Pot Cookbook for Busy Families",
        description: "Quick, easy meals that make dinner time manageable",
        amazonLink: "https://www.amazon.com/s?k=Instant+Pot+Cookbook+for+Busy+Families&ref=nb_sb_noss"
      },
      {
        name: "Strong as a Mother Book",
        description: "Empowering reminders of your strength and resilience",
        amazonLink: "https://www.amazon.com/s?k=Strong+as+a+Mother+Book&ref=nb_sb_noss"
      }
    ]
  },
  {
    id: "surviving-mom",
    title: "Surviving Mom",
    scoreRange: [10, 14],
    description: "Motherhood is tough and you're in the thick of it!",
    message: "Remember, surviving the hard phases IS good mothering. You're in a challenging season, but you're stronger than you know. Every day you show up for your children is a victory. Be gentle with yourself - you're doing better than you think.",
    image: "/images/surviving-mom.png",
    products: [
      {
        name: "Mom's One Line a Day Journal",
        description: "Capture precious moments without pressure",
        amazonLink: "https://www.amazon.com/s?k=Mom+One+Line+a+Day+Journal&ref=nb_sb_noss"
      },
      {
        name: "Bath Bombs Gift Set",
        description: "Well-deserved relaxation for those rare quiet moments",
        amazonLink: "https://www.amazon.com/s?k=Bath+Bombs+Gift+Set+for+Relaxation&ref=nb_sb_noss"
      },
      {
        name: "The Blessing of a Skinned Knee",
        description: "Gentle parenting wisdom for challenging times",
        amazonLink: "https://www.amazon.com/s?k=The+Blessing+of+a+Skinned+Knee+Parenting+Book&ref=nb_sb_noss"
      }
    ]
  }
];

export function getMomTypeByScore(score: number): MomType {
  return momTypes.find(type => 
    score >= type.scoreRange[0] && score <= type.scoreRange[1]
  ) || momTypes[0];
}
