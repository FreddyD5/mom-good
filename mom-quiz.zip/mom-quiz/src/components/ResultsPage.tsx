import { useState } from 'react';
import { Heart, Star, Share2, RotateCcw, Home, ExternalLink, Gift } from 'lucide-react';
import { MomType } from '../data/quizData';

interface ResultsPageProps {
  userName: string;
  score: number;
  momType: MomType;
  onRetakeQuiz: () => void;
  onResetQuiz: () => void;
}

export default function ResultsPage({ userName, score, momType, onRetakeQuiz, onResetQuiz }: ResultsPageProps) {
  const [showShareMessage, setShowShareMessage] = useState(false);

  const shareText = `I just discovered I'm a "${momType.title}"! 🌟 Take the "How Good of a Mom Are You?" quiz and celebrate your unique motherhood style! Every mom is amazing in her own way. 💕`;

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'How Good of a Mom Are You? Quiz Results',
          text: shareText,
          url: window.location.origin,
        });
      } catch (err) {
        console.log('Error sharing:', err);
        fallbackShare();
      }
    } else {
      fallbackShare();
    }
  };

  const fallbackShare = () => {
    navigator.clipboard.writeText(`${shareText} ${window.location.origin}`);
    setShowShareMessage(true);
    setTimeout(() => setShowShareMessage(false), 3000);
  };

  const getScoreColor = () => {
    if (score >= 35) return 'text-purple-600';
    if (score >= 25) return 'text-green-600';
    if (score >= 15) return 'text-blue-600';
    return 'text-rose-600';
  };

  const getScoreGradient = () => {
    if (score >= 35) return 'from-purple-500 to-purple-600';
    if (score >= 25) return 'from-green-500 to-green-600';
    if (score >= 15) return 'from-blue-500 to-blue-600';
    return 'from-rose-500 to-rose-600';
  };

  return (
    <div className="min-h-screen py-8 px-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <div className="flex items-center space-x-2 text-rose-600">
              <Star className="w-8 h-8 fill-current" />
              <Heart className="w-8 h-8 fill-current" />
              <Star className="w-8 h-8 fill-current" />
            </div>
          </div>
          <h1 className="text-3xl md:text-4xl font-bold text-gray-800 mb-2">
            Congratulations, {userName}! 🎉
          </h1>
          <p className="text-xl text-gray-600">
            Here are your beautiful results!
          </p>
        </div>

        {/* Main Results Card */}
        <div className="bg-white/90 backdrop-blur-sm rounded-3xl p-8 md:p-12 shadow-2xl border border-white/50 mb-8">
          {/* Score Display */}
          <div className="text-center mb-8">
            <div className={`text-6xl md:text-8xl font-bold ${getScoreColor()} mb-4`}>
              {score}
            </div>
            <div className="text-lg text-gray-600 mb-6">
              out of 40 points
            </div>
            <div className={`inline-block bg-gradient-to-r ${getScoreGradient()} text-white px-8 py-3 rounded-full text-xl font-bold shadow-lg`}>
              You're a {momType.title}! ✨
            </div>
          </div>

          {/* Mom Type Image and Description */}
          <div className="grid md:grid-cols-2 gap-8 items-center mb-8">
            <div className="text-center">
              <img 
                src={momType.image} 
                alt={momType.title}
                className="w-64 h-64 object-cover rounded-full mx-auto shadow-xl ring-8 ring-white/50"
              />
            </div>
            <div>
              <h2 className="text-2xl md:text-3xl font-bold text-gray-800 mb-4">
                {momType.description}
              </h2>
              <p className="text-lg text-gray-700 leading-relaxed">
                {momType.message}
              </p>
            </div>
          </div>
        </div>

        {/* Product Recommendations */}
        <div className="bg-white/90 backdrop-blur-sm rounded-3xl p-8 md:p-12 shadow-2xl border border-white/50 mb-8">
          <div className="text-center mb-8">
            <div className="flex justify-center mb-4">
              <Gift className="w-8 h-8 text-rose-600" />
            </div>
            <h3 className="text-2xl md:text-3xl font-bold text-gray-800 mb-4">
              Perfect Picks Just for You! 🛍️
            </h3>
            <p className="text-lg text-gray-600">
              We've curated these special recommendations to support your amazing {momType.title.toLowerCase()} journey
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {momType.products.map((product, index) => (
              <div key={index} className="bg-gradient-to-br from-rose-50 to-pink-50 rounded-2xl p-6 border border-rose-100 hover:shadow-lg transition-all duration-300 transform hover:scale-105">
                <div className="text-center">
                  <div className="bg-rose-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Gift className="w-8 h-8 text-rose-600" />
                  </div>
                  <h4 className="font-bold text-gray-800 mb-3 text-lg">
                    {product.name}
                  </h4>
                  <p className="text-gray-600 mb-4 text-sm leading-relaxed">
                    {product.description}
                  </p>
                  <a
                    href={product.amazonLink}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center bg-gradient-to-r from-orange-500 to-yellow-500 hover:from-orange-600 hover:to-yellow-600 text-white font-bold py-3 px-6 rounded-full transition-all duration-300 transform hover:scale-105 shadow-lg"
                  >
                    View on Amazon
                    <ExternalLink className="w-4 h-4 ml-2" />
                  </a>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="bg-white/90 backdrop-blur-sm rounded-3xl p-8 shadow-2xl border border-white/50">
          <div className="text-center mb-6">
            <h3 className="text-xl font-bold text-gray-800 mb-2">
              What would you like to do next? 💫
            </h3>
            <p className="text-gray-600">
              Share your results or take the quiz again anytime!
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button
              onClick={handleShare}
              className="flex items-center justify-center bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white font-bold py-4 px-8 rounded-full transition-all duration-300 transform hover:scale-105 shadow-lg"
            >
              <Share2 className="w-5 h-5 mr-2" />
              Share My Results! 📱
            </button>

            <button
              onClick={onRetakeQuiz}
              className="flex items-center justify-center bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white font-bold py-4 px-8 rounded-full transition-all duration-300 transform hover:scale-105 shadow-lg"
            >
              <RotateCcw className="w-5 h-5 mr-2" />
              Retake Quiz 🔄
            </button>

            <button
              onClick={onResetQuiz}
              className="flex items-center justify-center bg-gradient-to-r from-gray-500 to-gray-600 hover:from-gray-600 hover:to-gray-700 text-white font-bold py-4 px-8 rounded-full transition-all duration-300 transform hover:scale-105 shadow-lg"
            >
              <Home className="w-5 h-5 mr-2" />
              Start Over 🏠
            </button>
          </div>

          {showShareMessage && (
            <div className="mt-4 text-center">
              <div className="inline-block bg-green-100 text-green-800 px-4 py-2 rounded-full text-sm font-medium">
                ✓ Link copied to clipboard! Share with your mom friends! 💕
              </div>
            </div>
          )}
        </div>

        {/* Final Encouraging Message */}
        <div className="text-center mt-8">
          <div className="bg-gradient-to-r from-rose-500 to-pink-500 text-white rounded-2xl p-6 mx-auto max-w-2xl">
            <h3 className="text-xl font-bold mb-3">
              Remember, {userName}... 🌟
            </h3>
            <p className="text-lg leading-relaxed">
              There's no such thing as a perfect mom, but there are a million ways to be a great one. 
              You're already amazing, and every day you show up for your children is a victory worth celebrating! 💝
            </p>
          </div>
        </div>

        {/* Bottom Decorative Elements */}
        <div className="mt-12 flex justify-center space-x-8 opacity-60">
          <div className="text-4xl">🌸</div>
          <div className="text-4xl">💖</div>
          <div className="text-4xl">🌺</div>
          <div className="text-4xl">✨</div>
          <div className="text-4xl">🌼</div>
        </div>
      </div>
    </div>
  );
}
