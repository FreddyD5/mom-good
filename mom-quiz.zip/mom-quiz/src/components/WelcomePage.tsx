import { useState } from 'react';
import { Heart, Star, Users } from 'lucide-react';

interface WelcomePageProps {
  onStartQuiz: (name: string) => void;
}

export default function WelcomePage({ onStartQuiz }: WelcomePageProps) {
  const [name, setName] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name.trim()) {
      onStartQuiz(name.trim());
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="max-w-4xl mx-auto text-center">
        {/* Hero Image */}
        <div className="mb-8">
          <img 
            src="/images/hero-mom.jpg" 
            alt="Happy mother with children" 
            className="w-72 h-72 object-cover rounded-full mx-auto shadow-2xl ring-8 ring-white/50"
          />
        </div>

        {/* Main Content */}
        <div className="bg-white/80 backdrop-blur-sm rounded-3xl p-8 md:p-12 shadow-2xl border border-white/50">
          <div className="flex justify-center mb-6">
            <div className="flex items-center space-x-2 text-rose-600">
              <Heart className="w-8 h-8 fill-current" />
              <Star className="w-8 h-8 fill-current" />
              <Heart className="w-8 h-8 fill-current" />
            </div>
          </div>

          <h1 className="text-4xl md:text-6xl font-bold text-gray-800 mb-4">
            How Good of a
            <span className="block text-rose-600">Mom Are You?</span>
          </h1>

          <p className="text-xl md:text-2xl text-gray-600 mb-8 leading-relaxed">
            Discover your unique motherhood style and get personalized recommendations 
            to support your amazing journey as a mom! 💕
          </p>

          {/* Features */}
          <div className="grid md:grid-cols-3 gap-6 mb-10">
            <div className="flex flex-col items-center p-4">
              <div className="bg-rose-100 p-4 rounded-full mb-3">
                <Star className="w-8 h-8 text-rose-600" />
              </div>
              <h3 className="font-semibold text-gray-800 mb-2">Personalized Results</h3>
              <p className="text-gray-600 text-sm">Get insights tailored to your unique parenting style</p>
            </div>
            
            <div className="flex flex-col items-center p-4">
              <div className="bg-orange-100 p-4 rounded-full mb-3">
                <Heart className="w-8 h-8 text-orange-600" />
              </div>
              <h3 className="font-semibold text-gray-800 mb-2">Encouraging Approach</h3>
              <p className="text-gray-600 text-sm">Celebrate your strengths and support your growth</p>
            </div>
            
            <div className="flex flex-col items-center p-4">
              <div className="bg-pink-100 p-4 rounded-full mb-3">
                <Users className="w-8 h-8 text-pink-600" />
              </div>
              <h3 className="font-semibold text-gray-800 mb-2">Mom Community</h3>
              <p className="text-gray-600 text-sm">Join thousands of moms celebrating their journey</p>
            </div>
          </div>

          {/* Name Input Form */}
          <form onSubmit={handleSubmit} className="max-w-md mx-auto">
            <div className="mb-6">
              <label htmlFor="name" className="block text-lg font-medium text-gray-700 mb-3">
                What's your name, amazing mom? ✨
              </label>
              <input
                type="text"
                id="name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Enter your first name"
                className="w-full px-6 py-4 text-lg border-2 border-rose-200 rounded-full focus:border-rose-400 focus:outline-none transition-colors bg-white/90"
                required
              />
            </div>
            
            <button
              type="submit"
              disabled={!name.trim()}
              className="w-full bg-gradient-to-r from-rose-500 to-pink-500 hover:from-rose-600 hover:to-pink-600 disabled:from-gray-300 disabled:to-gray-400 text-white font-bold py-4 px-8 rounded-full text-lg transition-all duration-300 transform hover:scale-105 disabled:scale-100 shadow-lg disabled:cursor-not-allowed"
            >
              Start My Mom Quiz! 🌟
            </button>
          </form>

          <p className="text-sm text-gray-500 mt-6">
            Takes just 2 minutes • No email required • 100% encouraging results!
          </p>
        </div>

        {/* Bottom Decorative Elements */}
        <div className="mt-12 flex justify-center space-x-8 opacity-60">
          <div className="text-4xl">🌸</div>
          <div className="text-4xl">💝</div>
          <div className="text-4xl">🌺</div>
          <div className="text-4xl">💕</div>
          <div className="text-4xl">🌼</div>
        </div>
      </div>
    </div>
  );
}
