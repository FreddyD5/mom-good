import { useState } from 'react';
import { ArrowLeft, ArrowRight, Heart } from 'lucide-react';
import { quizQuestions } from '../data/quizData';

interface QuizPageProps {
  userName: string;
  onCompleteQuiz: (score: number) => void;
}

export default function QuizPage({ userName, onCompleteQuiz }: QuizPageProps) {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<number[]>(new Array(quizQuestions.length).fill(-1));
  const [selectedOption, setSelectedOption] = useState(-1);

  const question = quizQuestions[currentQuestion];
  const progress = ((currentQuestion + 1) / quizQuestions.length) * 100;
  const isLastQuestion = currentQuestion === quizQuestions.length - 1;
  const canProceed = selectedOption !== -1;

  const handleOptionSelect = (optionIndex: number) => {
    setSelectedOption(optionIndex);
    const newAnswers = [...answers];
    newAnswers[currentQuestion] = optionIndex;
    setAnswers(newAnswers);
  };

  const handleNext = () => {
    if (!canProceed) return;

    if (isLastQuestion) {
      // Calculate final score
      const totalScore = answers.reduce((sum, answerIndex, questionIndex) => {
        if (answerIndex === -1) return sum;
        return sum + quizQuestions[questionIndex].options[answerIndex].points;
      }, 0);
      onCompleteQuiz(totalScore);
    } else {
      setCurrentQuestion(prev => prev + 1);
      setSelectedOption(answers[currentQuestion + 1] ?? -1);
    }
  };

  const handlePrevious = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(prev => prev - 1);
      setSelectedOption(answers[currentQuestion - 1] ?? -1);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="max-w-4xl mx-auto w-full">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center mb-4">
            <Heart className="w-6 h-6 text-rose-500 fill-current mr-2" />
            <span className="text-lg font-medium text-gray-700">
              Hey {userName}! You're doing great! 
            </span>
            <Heart className="w-6 h-6 text-rose-500 fill-current ml-2" />
          </div>
          
          {/* Progress Bar */}
          <div className="bg-white/50 rounded-full h-3 mb-4 overflow-hidden">
            <div 
              className="bg-gradient-to-r from-rose-500 to-pink-500 h-full transition-all duration-500 ease-out"
              style={{ width: `${progress}%` }}
            />
          </div>
          
          <p className="text-sm text-gray-600">
            Question {currentQuestion + 1} of {quizQuestions.length}
          </p>
        </div>

        {/* Question Card */}
        <div className="bg-white/90 backdrop-blur-sm rounded-3xl p-8 md:p-12 shadow-2xl border border-white/50 mb-8">
          <div className="text-center mb-8">
            <h2 className="text-2xl md:text-3xl font-bold text-gray-800 mb-6 leading-relaxed">
              {question.question}
            </h2>
            
            <div className="w-16 h-1 bg-gradient-to-r from-rose-500 to-pink-500 mx-auto rounded-full"></div>
          </div>

          {/* Options */}
          <div className="space-y-4 max-w-3xl mx-auto">
            {question.options.map((option, index) => (
              <button
                key={index}
                onClick={() => handleOptionSelect(index)}
                className={`w-full text-left p-6 rounded-2xl border-2 transition-all duration-300 transform hover:scale-[1.02] ${
                  selectedOption === index
                    ? 'border-rose-400 bg-rose-50 shadow-lg'
                    : 'border-gray-200 bg-white hover:border-rose-200 hover:bg-rose-25'
                }`}
              >
                <div className="flex items-start">
                  <div className={`w-6 h-6 rounded-full border-2 mr-4 mt-1 flex-shrink-0 flex items-center justify-center ${
                    selectedOption === index 
                      ? 'border-rose-500 bg-rose-500' 
                      : 'border-gray-300'
                  }`}>
                    {selectedOption === index && (
                      <div className="w-3 h-3 bg-white rounded-full"></div>
                    )}
                  </div>
                  <div>
                    <p className="text-lg text-gray-800 leading-relaxed">
                      {option.text}
                    </p>
                    <p className="text-sm text-rose-600 font-medium mt-2">
                      {option.momType}
                    </p>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Navigation */}
        <div className="flex justify-between items-center">
          <button
            onClick={handlePrevious}
            disabled={currentQuestion === 0}
            className="flex items-center px-6 py-3 rounded-full border-2 border-gray-300 text-gray-600 hover:border-gray-400 hover:text-gray-800 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-300"
          >
            <ArrowLeft className="w-5 h-5 mr-2" />
            Previous
          </button>

          <div className="flex space-x-2">
            {quizQuestions.map((_, index) => (
              <div
                key={index}
                className={`w-3 h-3 rounded-full transition-all duration-300 ${
                  index === currentQuestion
                    ? 'bg-rose-500 scale-125'
                    : answers[index] !== -1
                    ? 'bg-green-400'
                    : 'bg-gray-300'
                }`}
              />
            ))}
          </div>

          <button
            onClick={handleNext}
            disabled={!canProceed}
            className="flex items-center px-6 py-3 rounded-full bg-gradient-to-r from-rose-500 to-pink-500 text-white hover:from-rose-600 hover:to-pink-600 disabled:from-gray-300 disabled:to-gray-400 disabled:cursor-not-allowed transition-all duration-300 transform hover:scale-105 disabled:scale-100 shadow-lg"
          >
            {isLastQuestion ? 'See My Results!' : 'Next'}
            {!isLastQuestion && <ArrowRight className="w-5 h-5 ml-2" />}
            {isLastQuestion && <span className="ml-2">✨</span>}
          </button>
        </div>

        {/* Encouraging Message */}
        <div className="text-center mt-8">
          <p className="text-gray-600 italic">
            "Every question you answer honestly is a step toward understanding your beautiful, unique approach to motherhood." 💝
          </p>
        </div>
      </div>
    </div>
  );
}
