import { useState } from 'react';
import WelcomePage from './components/WelcomePage';
import QuizPage from './components/QuizPage';
import ResultsPage from './components/ResultsPage';
import { getMomTypeByScore } from './data/quizData';
import './App.css';

export type AppState = 'welcome' | 'quiz' | 'results';

function App() {
  const [currentState, setCurrentState] = useState<AppState>('welcome');
  const [quizScore, setQuizScore] = useState(0);
  const [userName, setUserName] = useState('');

  const startQuiz = (name: string) => {
    setUserName(name);
    setCurrentState('quiz');
  };

  const completeQuiz = (score: number) => {
    setQuizScore(score);
    setCurrentState('results');
  };

  const resetQuiz = () => {
    setQuizScore(0);
    setUserName('');
    setCurrentState('welcome');
  };

  const retakeQuiz = () => {
    setQuizScore(0);
    setCurrentState('quiz');
  };

  const momType = getMomTypeByScore(quizScore);

  return (
    <div className="min-h-screen bg-gradient-to-br from-rose-50 via-pink-50 to-orange-50">
      {currentState === 'welcome' && (
        <WelcomePage onStartQuiz={startQuiz} />
      )}
      
      {currentState === 'quiz' && (
        <QuizPage 
          userName={userName}
          onCompleteQuiz={completeQuiz} 
        />
      )}
      
      {currentState === 'results' && (
        <ResultsPage 
          userName={userName}
          score={quizScore}
          momType={momType}
          onRetakeQuiz={retakeQuiz}
          onResetQuiz={resetQuiz}
        />
      )}
    </div>
  );
}

export default App;
